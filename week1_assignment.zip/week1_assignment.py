n =int(input("Enter the number you want: "))

def lower_triangular(n):
    for i in range(1, n + 1, 1):
        print('*' * i)
 
def upper_triangular(n):
    for i in range(n, 0, -1):
        print(" " * (n - i) + '*' * i)

def pyramid(n):
    for i in range (1, n+1):
        print(" " * (n - i) + '*' * (2 * i - 1))

lower_triangular(n)
print("Lower triangular pattern is completed \n")
upper_triangular(n)
print("Upper triangular pattern is completed \n")
pyramid(n)
print("Pyramid pattern is completed \n")